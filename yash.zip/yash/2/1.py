s = """"""
for i in range(10):
    x = input()
    s+= f"""\n<td>
                    <a href = "{x}.html">{x.upper()}</a>
                </td>"""
print(s)