<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php 
    $a = $_POST['size'];
    echo $a,"PATTERN";
    ?></title>
    <style>
    body{
        font-family:Monospace;
    }
    </style>
    <script>
        setInterval(function(){
            var colwor = "#";
            var color2 = "";
            var s = "0123456789ABCDEF";
            var ali = ["left" , "right" ,"center"];
            for(var i = 0;i<6;i++){
                colwor += s[Math.floor(Math.random()*16)];
                color2 = s[Math.floor(Math.random()*16)]+color2;
            }
            color2 = "#"+color2;
            
            document.getElementById('rand').style.backgroundColor=color2;
            document.getElementById('rand').style.color=colwor;
        },300);        
    </script>
</head>
<body id = 'rand'>
<form action = "./php1.php" method="post">
        <input type = 'text' name="size"/>
        <input type = "submit" value = "GO">
</form>
<br>
<marquee>
<?php
    $n = $_POST['size'];
    if($n%2==0){
        $n++;
    }
    $space = 1;
    $stars = $n/2;
    for($j =1;$j<=$n;$j++)
        echo"*";
    echo"<br>";    
    for($i = 1;$i<=$n/2;$i++){
        for($j =1;$j<=$stars;$j++)
            echo"*";
        for($j =1;$j<=$space;$j++)
            echo"&nbsp;";    
        for($j =1;$j<=$stars;$j++)
            echo"*";
        $stars--;
        $space+=2;           
        echo"<br>";
    }
    $stars +=2;
    $space -=4;
    for($i = 1;$i<$n/2-1;$i++){
        for($j =1;$j<=$stars;$j++)
            echo"*";
        for($j =1;$j<=$space;$j++)
            echo"&nbsp;";    
        for($j =1;$j<=$stars;$j++)
            echo"*";
        $stars++;
        $space-=2;           
        echo"<br>";
    }
    for($j =1;$j<=$n;$j++)
        echo"*";
    echo"<br>";
?>
</marquee>

</body>
</html>