def pagegen(s):
    d = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{s.upper()}</title>
</head>
<body>
<h1>{s}</h1>
</body>
</html>'''
    with open(f"{s}.html",'w+') as f:
        f.write(d)
    f.close()
c = " "
while(c):
    c = input("Page title")
    pagegen(c) 