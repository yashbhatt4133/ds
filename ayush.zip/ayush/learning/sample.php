<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Document</title>
    </head>
    <body>
        <?php
        
        // print_r($GLOBALS);
        // echo "Your name is ".$_POST['name']."<br/>";
        // $num=$_POST['number'];
        // if(is_numeric($num)){
        //     for($i =0;$i<$num;$i++){
        //         for($j=0;$j<$i;$j++){
        //             echo "*";
        //         }
        //         echo "<br/>";
        //     }
        // }
        // else{
        //     echo "Input is not a number";
        // }
    ?>
    </body>
</html>