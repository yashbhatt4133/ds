<?php
    $num=readline('Enter a number :');
    echo (sqrt($num));
?>